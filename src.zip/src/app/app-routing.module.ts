import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
//import { CatalogoComponent } from './catalogo/catalogo.component';
//import { CompraComponent } from './compra/compra.component';

const routes: Routes = [
 //{ path: '', component: FirstPageComponent },
 { path: 'login', component:LoginComponent }
 //{ path: 'catalogo', component: CatalogoComponent },
 //{ path: './login/login.component', component:LoginComponent },
 //{ path: './catalogo/catalogo.component', component: CatalogoComponent },
 //{ path: './catalogo/compra.component'omponent: CompraComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  providers: [],
  declarations: []
})

export class RoutesModule { }
