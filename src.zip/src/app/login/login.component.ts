import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { HttpService} from '../http.service';
import { Response } from '@angular/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  providers: [DataService]
})

export class LoginComponent implements OnInit{

  private usuarios: string [] = [];

  constructor(private httpService : HttpService) { }

  enviarForm(form){
    console.log ("entra al formulario");
    this.httpService.getDatos()
    .subscribe(
      (data: Response) => console.log(data)
    )
    return this.usuarios;

  }

  ngOnInit() {
  }
}

/*@Injectable()
export class DataService{


  constructor(private logService: LogService, ){}

  getUsers(){
    this.httpService.getDatos()
    .subscribe(
      (data: Response) => console.log(data)
    )
    return this.usuarios;
  }
}*/
